package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandExecutor;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.channels.SocketChannel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CreateGroupCommandTest {
    private SocketChannel channel;
    private CommandExecutor executor;

    @BeforeEach
    void setup() {
        channel = mock(SocketChannel.class);
        executor = new CommandExecutor();
    }

    @Test
    void testExecuteCommandWhenUserNotLoggedIn() {
        String input = "create-group test-group user1 user2";

        when(UserSessionManager.getInstance().isLoggedIn(channel)).thenReturn(false);

        String result = executor.execute(input, channel);

        assertEquals("User not logged in", result, "The result should be 'User not logged in'");
    }
}

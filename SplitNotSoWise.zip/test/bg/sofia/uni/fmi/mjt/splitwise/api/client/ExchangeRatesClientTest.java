package bg.sofia.uni.fmi.mjt.splitwise.api.client;

import bg.sofia.uni.fmi.mjt.splitwise.api.env.EnvironmentVariableLoader;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.ExchangeAPIException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.api.InactiveAccountException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.handler.HttpStatusCode;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.Reader;
import java.io.StringReader;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

// TODO
public class ExchangeRatesClientTest {
    private static HttpClient mockHttpClient;
    private static HttpResponse<String> mockResponse;
    private static ExchangeRatesClient newsFeedClient;
    private static final String[] KEYWORDS = {"technology", "science"};

    @BeforeAll
    static void setUp() {
        Reader reader = new StringReader("NEWS_API_KEY=valid-api-key-for-news-feed-api");
        EnvironmentVariableLoader.loadEnvironmentVariables(reader);
        mockHttpClient = mock();
        mockResponse = mock();

        newsFeedClient = new ExchangeRatesClient(mockHttpClient);
    }

    @Test
    void testGetFeedSuccess() throws Exception {
        String jsonResponse = "{ \"status\": \"ok\", \"articles\": [] }";
        when(mockResponse.statusCode()).thenReturn(HttpStatusCode.OK.code());
        when(mockResponse.body()).thenReturn(jsonResponse);
        when(mockHttpClient.send(any(HttpRequest.class), eq(HttpResponse.BodyHandlers.ofString()))).thenReturn(
            mockResponse);

        NewsFeed result = newsFeedClient.getFeed(KEYWORDS);

        assertNotNull(result);
        assertTrue(result.getArticles().isEmpty(), "Articles should be empty in the valid response.");

        // Test if the status works fine
        assertEquals(new NewsFeed(0, new NewsArticle[] {
                new NewsArticle(new NewsSource("1", "a"), "a", "a", "a", "a", "a", "a", "a")}).isSuccess(),
            result.isSuccess(),
            "Expected non-error result to return ok status");
    }

    @Test
    void testGetFeedErrorResponse() throws Exception {
        String errorResponse =
            "{ \"status\": \"error\", \"code\": \"apiKeyInvalid\", \"message\": \"Invalid API key\" }";
        when(mockResponse.statusCode()).thenReturn(HttpStatusCode.UNAUTHORIZED.code());
        when(mockResponse.body()).thenReturn(errorResponse);
        when(mockHttpClient.send(any(HttpRequest.class), eq(HttpResponse.BodyHandlers.ofString()))).thenReturn(
            mockResponse);

        ExchangeAPIException thrown =
            assertThrows(ExchangeAPIException.class, () -> newsFeedClient.getFeed(KEYWORDS));
        assertInstanceOf(InactiveAccountException.class, thrown.getCause(),
            "Expected exception of type APIKeyInvalidException.");
    }

    @Test
    void testGetFeedNetworkError() throws Exception {
        when(mockHttpClient.send(any(HttpRequest.class), eq(HttpResponse.BodyHandlers.ofString())))
            .thenThrow(new RuntimeException("Network error"));

        assertThrows(ExchangeAPIException.class, () -> newsFeedClient.getFeed(KEYWORDS),
            "Expected ExchangeRatesAPIException to be thrown.");
    }

    @Test
    void testGetFeedWithCustomParameters() throws Exception {
        String jsonResponse = "{ \"status\": \"ok\", \"articles\": [] }";
        when(mockResponse.statusCode()).thenReturn(HttpStatusCode.OK.code());
        when(mockResponse.body()).thenReturn(jsonResponse);
        when(mockHttpClient.send(any(HttpRequest.class), eq(HttpResponse.BodyHandlers.ofString()))).thenReturn(
            mockResponse);

        NewsFeed result = newsFeedClient.getFeed(KEYWORDS, "technology", "us", 10, 1);

        assertNotNull(result);
        assertTrue(result.getArticles().isEmpty(), "Articles should be empty in the valid response.");
        assertEquals(0, result.getTotalResults(), "Articles should be empty in the valid response.");
    }
}

package bg.sofia.uni.fmi.mjt.splitwise.app.command;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.HelpCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.UnknownCommand;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;

public class CommandTypeTest {
    private static final String INVALID_ARGS =
        "Invalid count of arguments: \"%s\" expects %d arguments. Example: \"%s\"";
    private static final String INSUFFICIENT_ARGS =
        "Invalid count of arguments: \"%s\" expects at least %d arguments. Example: \"%s\"";

    @Test
    void fromStringValidCommand() {
        CommandType result = CommandType.fromString("login");
        assertEquals(CommandType.LOGIN, result);
    }

    @Test
    void fromStringInvalidCommand() {
        CommandType result = CommandType.fromString("invalid");
        assertNull(result);
    }

    @Test
    void checkArgumentsExactValid() {
        CommandType commandType = CommandType.LOGIN;
        String result = commandType.checkArguments(2);
        assertNull(result);
    }

    @Test
    void checkArgumentsExactInvalid() {
        CommandType commandType = CommandType.LOGIN;
        String result = commandType.checkArguments(1);
        assertEquals(String.format(INVALID_ARGS, "login", 2, "login <username> <password>"), result);
    }

    @Test
    void checkArgumentsAtLeastValid() {
        CommandType commandType = CommandType.CREATE_GROUP;
        String result = commandType.checkArguments(3);
        assertNull(result);
    }

    @Test
    void checkArgumentsAtLeastInvalid() {
        CommandType commandType = CommandType.CREATE_GROUP;
        String result = commandType.checkArguments(1);
        assertEquals(String.format(INSUFFICIENT_ARGS, "create-group", 2,
            "create-group <group_name> <username> <username> ..."), result);
    }

    @Test
    void getCommandHelp() {
        String[] args = {};
        Command result = CommandType.getCommand("help", null, args);
        assertInstanceOf(HelpCommand.class, result);
    }

    @Test
    void getCommandInvalidCommand() {
        String[] args = {"any"};
        Command result = CommandType.getCommand("invalid", null, args);
        assertInstanceOf(UnknownCommand.class, result);
    }
}

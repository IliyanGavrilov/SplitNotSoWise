package bg.sofia.uni.fmi.mjt.splitwise.api.client;

import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.ExchangeAPIException;
import org.junit.jupiter.api.Test;

import java.net.URI;
import java.net.URISyntaxException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

// TODO
public class ExchangeRatesURITest {
    @Test
    void testBuildUriWithMandatoryParameters() throws URISyntaxException, ExchangeAPIException {
        ExchangeRatesURI uri = new ExchangeRatesURI.NewsFeedURIBuilder(new String[] {"test"}, "test-api-key").build();
        URI result = uri.buildURI();

        String expected = "https://newsapi.org/v2/top-headlines?q=test&apiKey=test-api-key";
        assertEquals(expected, result.toString(), "URI should match expected mandatory parameter format");
    }

    @Test
    void testBuildUriWithAllParameters() throws ExchangeAPIException, URISyntaxException {
        String[] keywords = {"test"};
        String apiKey = "test-api-key";
        String country = "us";
        String category = "technology";
        int pageSize = 20;
        int page = 2;

        ExchangeRatesURI uri = new ExchangeRatesURI.NewsFeedURIBuilder(keywords, apiKey)
            .withCountry(country)
            .withCategory(category)
            .withPageSize(pageSize)
            .withPage(page)
            .build();

        URI result = uri.buildURI();

        String expected =
            "https://newsapi.org/v2/top-headlines?q=test&apiKey=test-api-key&category=technology&country=us&pageSize=20&page=2";
        assertEquals(expected, result.toString(), "URI should match expected format with all parameters");
    }

    @Test
    void testBuildUriWithBlankParameters() throws ExchangeAPIException, URISyntaxException {
        String[] keywords = {"test"};
        String apiKey = "test-api-key";
        String country = "";
        String category = "";
        int pageSize = 20;
        int page = 2;

        ExchangeRatesURI uri = new ExchangeRatesURI.NewsFeedURIBuilder(keywords, apiKey)
            .withCountry(country)
            .withCategory(category)
            .withPageSize(pageSize)
            .withPage(page)
            .build();

        URI result = uri.buildURI();

        String expected = "https://newsapi.org/v2/top-headlines?q=test&apiKey=test-api-key&pageSize=20&page=2";
        assertEquals(expected, result.toString(), "URI should match expected format with all parameters");
    }

    @Test
    void testBuildUriWithInvalidPageSize() {
        assertThrows(ExchangeAPIException.class,
            () -> new ExchangeRatesURI.NewsFeedURIBuilder(new String[] {"test"}, "test-api-key")
                .withPageSize(0), "Page size below minimum should throw NewsAPIException");

        assertThrows(ExchangeAPIException.class,
            () -> new ExchangeRatesURI.NewsFeedURIBuilder(new String[] {"test"}, "test-api-key")
                .withPageSize(101), "Page size below minimum should throw NewsAPIException");
    }

    @Test
    void testBuildUriWithInvalidPageIndex() {
        assertThrows(ExchangeAPIException.class,
            () -> new ExchangeRatesURI.NewsFeedURIBuilder(new String[] {"test"}, "test-api-key")
                .withPage(-1), "Negative page index should throw NewsAPIException");
    }

    @Test
    void testBuildUriWithEmptyKeywords() {
        assertThrows(ExchangeAPIException.class,
            () -> new ExchangeRatesURI.NewsFeedURIBuilder(new String[] {}, "test-api-key"),
            "Empty keywords should throw NewsAPIException");
    }

    @Test
    void testBuildUriWithNullKeywords() {
        assertThrows(ExchangeAPIException.class,
            () -> new ExchangeRatesURI.NewsFeedURIBuilder(null, "test-api-key"),
            "Null keywords should throw NewsAPIException");
    }
}

package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandExecutor;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.channels.SocketChannel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AddFriendCommandTest {
    private SocketChannel channel;
    private CommandExecutor executor;

    @BeforeEach
    void setup() {
        channel = mock(SocketChannel.class);
        executor = new CommandExecutor();
    }

    @Test
    void testExecuteCommandWithUnregisteredUser() {
        String input = "add-friend user1";

        when(InMemoryExpenseRepository.getInstance().isRegistered(any())).thenReturn(false);

        String result = executor.execute(input, channel);

        assertEquals("User is not registered!", result, "The result should be 'User is not registered!'");
    }
}

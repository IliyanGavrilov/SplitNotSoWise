package bg.sofia.uni.fmi.mjt.splitwise.app.command;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.UnknownCommand;
import org.junit.jupiter.api.Test;

import java.nio.channels.SocketChannel;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class CommandFactoryTest {
    @Test
    void testNewCommandEmptyInput() {
        String input = "";
        SocketChannel channel = null;
        Command command = CommandFactory.newCommand(channel, input);

        assertInstanceOf(UnknownCommand.class, command, "Empty input should result in UnknownCommand");
    }

    @Test
    void testNewCommandInvalidCommand() {
        String input = "invalid-command arg1 arg2";
        SocketChannel channel = null;
        Command command = CommandFactory.newCommand(channel, input);

        assertInstanceOf(UnknownCommand.class, command, "Invalid command should result in UnknownCommand");
    }
}
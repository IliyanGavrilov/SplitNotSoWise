package bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class EncryptionTest {
    private static final String PASSWORD = "password123";
    private static final String SALT = "somesalt";

    @Test
    void testEncryptWithValidPasswordAndSalt() {
        String hashedPassword = Encryption.encrypt(PASSWORD, SALT);
        assertNotNull(hashedPassword, "Hash should not be null");
    }

    @Test
    void testEncryptWithSamePasswordAndSalt() {
        String hashedPassword1 = Encryption.encrypt(PASSWORD, SALT);
        String hashedPassword2 = Encryption.encrypt(PASSWORD, SALT);
        assertEquals(hashedPassword1, hashedPassword2, "Hash should be the same for the same password and salt");
    }

    @Test
    void testEncrypt_withDifferentSalt() {
        String hashedPassword1 = Encryption.encrypt(PASSWORD, SALT);
        String hashedPassword2 = Encryption.encrypt(PASSWORD, "differentSalt");
        assertNotEquals(hashedPassword1, hashedPassword2, "Hash should be different for different salts");
    }

    @Test
    void testEncryptWithEmptyPassword() {
        String hashedPassword = Encryption.encrypt("", SALT);
        assertNotNull(hashedPassword, "Hash should not be null for empty password");
    }

    @Test
    void testEncryptWithEmptySalt() {
        String hashedPassword = Encryption.encrypt(PASSWORD, "");
        assertNotNull(hashedPassword, "Hash should not be null for empty salt");
    }
}

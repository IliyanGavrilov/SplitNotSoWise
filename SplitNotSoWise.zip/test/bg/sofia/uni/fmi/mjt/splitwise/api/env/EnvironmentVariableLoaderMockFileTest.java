package bg.sofia.uni.fmi.mjt.splitwise.api.env;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class EnvironmentVariableLoaderMockFileTest {
    // Kind of a bad unit test but no other way without mock static
    private static final Path ENV_FILE_PATH = Path.of("resources" + File.separator + ".env");
    private String savedContent = null;

    @BeforeEach
    void setUp() throws IOException {
        if (Files.exists(ENV_FILE_PATH)) {
            savedContent = Files.readString(ENV_FILE_PATH);
            Files.delete(ENV_FILE_PATH);
        }
    }

    @AfterEach
    void cleanUp() throws IOException {
        if (savedContent != null) {
            Files.writeString(ENV_FILE_PATH, savedContent);
        }
    }

    @Test
    void testLoadEnvironmentVariables() throws IOException {
        String content = "VALID_KEY=valid-value1234567890\n";

        if (Files.notExists(ENV_FILE_PATH.getParent())) {
            Files.createDirectories(ENV_FILE_PATH.getParent());
        }

        Files.writeString(ENV_FILE_PATH, content);
        EnvironmentVariableLoader.loadEnvironmentVariables();

        assertEquals("valid-value1234567890", EnvironmentVariableLoader.get("VALID_KEY"),
            "Expected value to be loaded properly");

        // Clean up
        if (Files.exists(ENV_FILE_PATH)) {
            Files.delete(ENV_FILE_PATH);
        }
    }

    @Test
    void testLoadEnvironmentVariablesWithIOException() {
        assertThrows(UncheckedIOException.class, EnvironmentVariableLoader::loadEnvironmentVariables,
            "Expected UncheckedIOException when the file is missing and an IOException occurs.");
    }
}

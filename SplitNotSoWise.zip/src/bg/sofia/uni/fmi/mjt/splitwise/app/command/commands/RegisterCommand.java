package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.Encryption;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;

import java.util.Arrays;

public class RegisterCommand extends Command {
    private static final int USERNAME_IDX = 0;
    private static final int PASSWORD_IDX = 1;
    private static final int NICKNAME_IDX = 2;

    public RegisterCommand(String[] args) {
        super(args, CommandType.REGISTER, null);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        // Maybe can make it if user is logged in he can't register an account?
//        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
//            return jsonifyArguments(ERROR, NOT_LOGGED);
//        }

        String nickname = String.join(" ", Arrays.copyOfRange(args, NICKNAME_IDX, args.length));

        if (InMemoryExpenseRepository.getInstance()
            .isRegistered(new User(args[USERNAME_IDX], args[PASSWORD_IDX], nickname))) {
            return jsonifyArguments(ERROR, "Username already exists!");
        }

        // Generate random salt instead of username salt?
        String encryptedPassword = Encryption.encrypt(args[PASSWORD_IDX], args[USERNAME_IDX]);

        User newUser = new User(args[USERNAME_IDX], encryptedPassword, nickname);
        InMemoryExpenseRepository.getInstance().addUser(newUser);

        return jsonifyArguments(OK, "User registered successfully");
    }
}

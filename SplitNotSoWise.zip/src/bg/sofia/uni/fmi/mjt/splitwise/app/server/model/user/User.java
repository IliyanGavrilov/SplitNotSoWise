package bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user;

import java.util.Objects;

// I don't want to have a getter for password, but I guess it's fine
public record User(String username, String password, String nickname, String currency) {
    public User(String username, String password, String nickname) {
        this(username, password, nickname, "LV");
    }

    public boolean passwordsMatch(User other) {
        return this.password.equals(other.password());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        User that = (User) o;

        return Objects.equals(username, that.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }
}

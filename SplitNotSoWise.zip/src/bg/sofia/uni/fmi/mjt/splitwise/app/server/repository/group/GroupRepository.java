package bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.group;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.Group;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.GroupType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class GroupRepository {
    private static final String FILE_PATH = "resources/groups.json";
    private static final int FRIENDSHIP_GROUP_SIZE = 2;
    private final Map<User, Set<Group>> groups = new HashMap<>();
    private final Gson gson; // Different instance so that we can use it in another thread
    private static GroupRepository instance;

    private Set<Group> filterGroups(User user, Predicate<Group> predicate) {
        return groups.getOrDefault(user, Set.of()).stream()
            .filter(predicate)
            .collect(Collectors.toSet());
    }

    private void loadFromFile() {
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            return; // No data yet
        }

        try (Reader reader = new FileReader(FILE_PATH)) {
            GroupData loadedData = gson.fromJson(reader, GroupData.class);

            if (loadedData != null) {
                Map<User, Set<Group>> loadedGroups = loadedData.groups();

                if (loadedGroups != null) {
                    groups.putAll(loadedGroups);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error loading data: ", e);
        }
    }

    private synchronized void saveToFile() {
        GroupData dataToSave = new GroupData(groups);

        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(dataToSave, writer);
        } catch (IOException e) {
            throw new RuntimeException("Error saving data: ", e);
        }
    }

    private void startSaveThread() {
        new Thread(this::saveToFile).start();
    }

    private GroupRepository() {
        gson = new GsonBuilder().setPrettyPrinting().create();
        loadFromFile();
    }

    public static GroupRepository getInstance() {
        if (instance == null) {
            instance = new GroupRepository();
        }

        return instance;
    }

    public void addUser(User user) {
        if (!groups.containsKey(user)) {
            groups.put(user, new HashSet<>());
            InMemoryExpenseRepository.getInstance().addUser(user);
            startSaveThread();
        }
    }

    public void addGroup(User user, Group group) {
        addUser(user);

        groups.get(user).add(group);
        Set<User> users = group.usersExcept(user);

        for (User u : users) {
            addUser(u);
            groups.get(u).add(group);
        }

        startSaveThread();
    }

    public Set<Group> getGroups(User user) {
        return filterGroups(user, _ -> true);
    }

    public Set<Group> getTwoPersonGroups(User user) {
        return filterGroups(user, group -> group.size() == FRIENDSHIP_GROUP_SIZE && group.type() == GroupType.FRIEND);
    }

    public Set<Group> getMultiPersonGroups(User user) {
        return filterGroups(user, group -> group.size() > FRIENDSHIP_GROUP_SIZE && group.type() == GroupType.GROUP);
    }

    public Group getGroup(User u, Group group) {
        if (group.type() == GroupType.FRIEND) {
            for (Group g : getTwoPersonGroups(u)) {
                if (group.users().equals(g.users()) || group.equals(g)) {
                    return g;
                }
            }
        } else if (group.type() == GroupType.GROUP) {
            for (Group g : getMultiPersonGroups(u)) {
                if (group.users().equals(g.users()) || group.equals(g)) {
                    return g;
                }
            }
        } else { // null
            for (Group g : groups.get(u)) {
                if (group.users().equals(g.users()) || group.equals(g)) {
                    return g;
                }
            }
        }
        return null;
    }
}

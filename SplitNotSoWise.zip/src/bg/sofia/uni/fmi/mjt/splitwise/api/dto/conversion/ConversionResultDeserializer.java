package bg.sofia.uni.fmi.mjt.splitwise.api.dto.conversion;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

public class ConversionResultDeserializer implements JsonDeserializer<ConversionResult> {
    @Override
    public ConversionResult deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws
        JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();

        double result = jsonObject.get("result").getAsDouble();

        JsonObject queryObject = jsonObject.getAsJsonObject("query");
        String from = queryObject.get("from").getAsString();
        String to = queryObject.get("to").getAsString();

        JsonObject infoObject = jsonObject.getAsJsonObject("info");
        long timestamp = infoObject.get("timestamp").getAsLong();
        double rate = infoObject.get("rate").getAsDouble();

        // Create the ConversionDetails object
        ConversionDetails details = new ConversionDetails(from, to, timestamp, rate);

        // Return a new ConversionResult object
        return new ConversionResult(result, details);
    }
}
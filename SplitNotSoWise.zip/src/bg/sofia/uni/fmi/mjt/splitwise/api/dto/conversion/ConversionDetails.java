package bg.sofia.uni.fmi.mjt.splitwise.api.dto.conversion;

public class ConversionDetails {
    String from;
    String to;
    long timestamp;
    double rate;

    public ConversionDetails(String from, String to, long timestamp, double rate) {
        this.from = from;
        this.to = to;
        this.timestamp = timestamp;
        this.rate = rate;
    }
}

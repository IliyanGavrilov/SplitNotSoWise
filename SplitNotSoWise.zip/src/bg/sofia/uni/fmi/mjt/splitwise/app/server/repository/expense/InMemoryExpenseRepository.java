package bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense.Expense;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.group.GroupRepository;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class InMemoryExpenseRepository implements ExpenseRepository {
    private static final double EPSILON = 0.001;
    private static final String FILE_PATH = "resources/expenses.json";
    private final Map<User, List<Expense>> expenses = new HashMap<>(); // For history of payments
    private final Map<User, Map<User, Double>> amountsOwed = new HashMap<>(); // Outer key is paidBy, inner is payers
    private final Gson gson; // Different instance so that we can use it in another thread
    private static ExpenseRepository instance;

    private Map<User, Double> filterStatus(User user, Predicate<Double> predicate) {
        return amountsOwed.getOrDefault(user, new HashMap<>()).entrySet().stream()
            .filter(entry -> predicate.test(entry.getValue()))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private void loadFromFile() {
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            return; // No data yet
        }

        try (Reader reader = new FileReader(FILE_PATH)) {
            ExpenseData loadedData = gson.fromJson(reader, ExpenseData.class);

            if (loadedData != null) {
                Map<User, List<Expense>> loadedExpenses = loadedData.expenses();
                Map<User, Map<User, Double>> loadedAmountsOwed = loadedData.amountsOwed();

                if (loadedExpenses != null) {
                    expenses.putAll(loadedExpenses);
                }
                if (loadedAmountsOwed != null) {
                    amountsOwed.putAll(loadedAmountsOwed);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error loading data: ", e);
        }
    }

    private synchronized void saveToFile() {
        ExpenseData dataToSave = new ExpenseData(expenses, amountsOwed);

        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(dataToSave, writer);
        } catch (IOException e) {
            throw new RuntimeException("Error saving data: ", e);
        }
    }

    private void startSaveThread() {
        new Thread(this::saveToFile).start();
    }

    private InMemoryExpenseRepository() {
        gson = new GsonBuilder().setPrettyPrinting().create();
        loadFromFile();
    }

    public static ExpenseRepository getInstance() {
        if (instance == null) {
            instance = new InMemoryExpenseRepository();
        }

        return instance;
    }

    @Override
    public void addUser(User user) {
        if (!expenses.containsKey(user) && !amountsOwed.containsKey(user)) {
            expenses.put(user, new LinkedList<>());
            amountsOwed.put(user, new HashMap<>());
            GroupRepository.getInstance().addUser(user);
            startSaveThread();
        }
    }

    @Override
    public void addExpense(Expense expense) {
        User credited = expense.getCredited();
        Double amount = expense.getAmount() / expense.getGroup().size();

        addUser(credited);
        expenses.get(credited).add(expense);

        for (User debited : expense.getDebited(credited)) {
            addUser(debited);
            // The person who paid sees how much the others owe him
            amountsOwed.get(credited).put(debited, amountsOwed.get(credited).getOrDefault(debited, 0.0) + amount);

            // The person who owes money can see how much they owe to the person that paid
            amountsOwed.get(debited).put(credited, amountsOwed.get(debited).getOrDefault(credited, 0.0) - amount);
        }

        startSaveThread();
    }

    @Override
    public void pay(Expense expense, User debited) {
        User credited = expense.getCredited();
        double amount = expense.getAmount();

        addUser(credited);
        addUser(debited);

        amountsOwed.get(credited).put(debited, amountsOwed.get(credited).getOrDefault(debited, 0.0) - amount);
        amountsOwed.get(debited).put(credited, amountsOwed.get(debited).getOrDefault(credited, 0.0) + amount);

        // If we want to save pay backs to history
        // expenses.get(credited).add(expense);

        startSaveThread();
    }

    @Override
    public Double getDebtStatus(User credited, User debited) {
        addUser(credited);
        addUser(debited);

        return amountsOwed.getOrDefault(credited, new HashMap<>()).getOrDefault(debited, 0.0);
    }

    @Override
    public Map<User, Double> getStatus(User user) {
        return filterStatus(user, _ -> true);
    }

    @Override
    public Map<User, Double> getStatusCreditsOnly(User user) {
        return filterStatus(user, val -> val > 0);
    }

    @Override
    public Map<User, Double> getStatusEvenOnly(User user) {
        return filterStatus(user, val -> Math.abs(val) < EPSILON);
    }

    @Override
    public Map<User, Double> getStatusDebtsOnly(User user) {
        return filterStatus(user, val -> val < 0);
    }

    @Override
    public List<Expense> getHistory(User user) {
        return expenses.getOrDefault(user, new LinkedList<>());
    }

    @Override
    public boolean isRegistered(User user) {
        return expenses.containsKey(user) && amountsOwed.containsKey(user);
    }

    @Override
    public boolean validatePassword(User user) {
        // O(N) needs to be fixed
        for (User u : expenses.keySet()) {
            if (u.equals(user)) {
                return u.passwordsMatch(user);
            }
        }

        throw new RuntimeException("User is not registered!");
    }

    @Override
    public User getUser(User user) {
        // O(N) needs to be fixed
        for (User u : expenses.keySet()) {
            if (u.equals(user)) {
                return u;
            }
        }

        throw new RuntimeException("User is not registered!");
    }
}

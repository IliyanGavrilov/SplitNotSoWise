package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense.Expense;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;

import java.nio.channels.SocketChannel;

public class PayedCommand extends Command {
    private static final double EPSILON = 0.001;
    private static final int AMOUNT_IDX = 0;
    private static final int USERNAME_IDX = 1;

    public PayedCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.PAYED, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, NOT_LOGGED);
        }

        User runner = UserSessionManager.getInstance().getUser(socket);
        User debited = InMemoryExpenseRepository.getInstance().getUser(new User(args[USERNAME_IDX], "", ""));

        InMemoryExpenseRepository.getInstance().pay(new Expense(-Double.parseDouble(args[AMOUNT_IDX]),
            runner, null, "Pay back"), debited);

        double amount = InMemoryExpenseRepository.getInstance().getDebtStatus(runner, debited);

        String currStatus;
        if (Math.abs(amount) < EPSILON) {
            currStatus = "Equal";
        } else if (amount > 0) {
            currStatus = "Owes you " + amount + runner.currency();
        } else { // (amount < 0)
            currStatus = "You owe " + amount + runner.currency();
        }

        return jsonifyArguments(OK, debited.nickname() + " (" + debited.username() + ") payed you " +
            args[AMOUNT_IDX] + runner.currency() + "\nCurrent status: " + currStatus);
    }
}

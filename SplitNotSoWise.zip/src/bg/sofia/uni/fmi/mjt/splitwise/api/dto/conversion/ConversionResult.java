package bg.sofia.uni.fmi.mjt.splitwise.api.dto.conversion;

import bg.sofia.uni.fmi.mjt.splitwise.api.dto.BaseResponse;

public class ConversionResult extends BaseResponse {
    private static final boolean STATUS = true;
    double result;
    ConversionDetails details;

    public ConversionResult(double result, ConversionDetails details) {
        super(STATUS);
        this.result = result;
        this.details = details;
    }
}

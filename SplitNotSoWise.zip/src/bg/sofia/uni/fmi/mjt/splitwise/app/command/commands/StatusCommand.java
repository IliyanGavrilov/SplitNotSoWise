package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.nio.channels.SocketChannel;

public class StatusCommand extends Command {
    public StatusCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.GET_STATUS, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, NOT_LOGGED);
        }
        User runner = UserSessionManager.getInstance().getUser(socket);

        // InMemoryExpenseRepository.getInstance().ge
        return jsonifyArguments(ERROR, "");
    }
}

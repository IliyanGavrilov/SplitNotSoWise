package bg.sofia.uni.fmi.mjt.splitwise.api.dto;

import com.google.gson.annotations.SerializedName;

public class BaseResponse {
    @SerializedName("success")
    private final boolean status;

    public BaseResponse(boolean status) {
        this.status = status;
    }

    public boolean isSuccess() {
        return status;
    }
}

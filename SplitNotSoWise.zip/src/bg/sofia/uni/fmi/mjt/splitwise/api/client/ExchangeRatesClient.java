package bg.sofia.uni.fmi.mjt.splitwise.api.client;

import bg.sofia.uni.fmi.mjt.splitwise.api.dto.BaseResponse;
import bg.sofia.uni.fmi.mjt.splitwise.api.dto.error.ErrorResponse;
import bg.sofia.uni.fmi.mjt.splitwise.api.env.EnvironmentVariableLoader;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.ExchangeAPIException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.handler.ExceptionFactory;
import bg.sofia.uni.fmi.mjt.splitwise.exception.handler.HttpStatusCode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/ /TODO

public class ExchangeRatesClient {
    private static final String API_KEY_NAME = "EXCHANGE_API_KEY";
    private static final String API_KEY = EnvironmentVariableLoader.get(API_KEY_NAME);

    private static final Gson GSON = new Gson();

    private final HttpClient newsHttpClient;

    public ExchangeRatesClient(HttpClient newsHttpClient) {
        this.newsHttpClient = newsHttpClient;
    }

    public NewsFeed getFeed(String[] keywords) throws ExchangeAPIException {
        return getFeed(keywords, null, null, null, null);
    }

    public NewsFeed getFeed(String[] keywords, String category, String country, Integer pageSize, Integer page)
        throws ExchangeAPIException {
        HttpResponse<String> response;

        try {
            URI uri = new ExchangeRatesURI.ExchangeRatesURIBuilder(keywords, API_KEY)
                .withCategory(category)
                .withCountry(country)
                .withPageSize(pageSize)
                .withPage(page)
                .build()
                .buildURI();

            HttpRequest request = HttpRequest.newBuilder().uri(uri).build();

            response = newsHttpClient.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            throw new ExchangeAPIException("Could not retrieve news feed!", e);
        }

        BaseResponse br = GSON.fromJson(response.body(), BaseResponse.class);

        if (response.statusCode() == HttpStatusCode.OK.code() && br.isSuccess()) {
            return GSON.fromJson(response.body(), NewsFeed.class);
        }

        JsonObject jsonObject = JsonParser.parseString(response.body()).getAsJsonObject();

        JsonObject name2 = jsonObject.getAsJsonObject("error");
        int code = name2.get("code").getAsInt();
        String message = name2.get("info").getAsString();

        throw ExceptionFactory.createHttpException(response.statusCode(),
            GSON.fromJson(response.body(), ErrorResponse.class));
    }
}

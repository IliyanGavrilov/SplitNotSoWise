package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;

import java.nio.channels.SocketChannel;

public class CreateGroupCommand extends Command {
    public CreateGroupCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.CREATE_GROUP, socket);
    }

    @Override
    public String execute() {
        return executeAddGroup();
    }
}

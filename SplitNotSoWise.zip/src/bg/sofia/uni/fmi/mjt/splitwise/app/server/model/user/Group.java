package bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user;

import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.expense.UserNotInGroupException;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public record Group(String name, Set<User> users, GroupType type) {
    public Group(String name, Set<User> users, GroupType type) {
        if (name.isBlank()) {
            this.type = GroupType.FRIEND;
            this.name = String.valueOf(UUID.randomUUID());
        } else {
            this.type = GroupType.GROUP;
            this.name = name;
        }
        this.users = users;
    }

    public Group(String name, Set<User> users) {
        this(name, users, null);
    }

    public Set<User> usersExcept(User user) {
        Set<User> usersWithoutCredited = new HashSet<>(users);

        if (usersWithoutCredited.remove(user)) {
            return usersWithoutCredited;
        }

        throw new UserNotInGroupException("Given user is not in group!");
    }

    public int size() {
        return users.size();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Group that = (Group) o;

        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}

package bg.sofia.uni.fmi.mjt.splitwise.app.command;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.json.GsonSingleton;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.json.JsonResponse;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.Group;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.group.GroupRepository;

import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class Command {
    private static final int USERNAME_IDX = 1;
    protected static final String ERROR = "ERROR";
    protected static final String OK = "OK";
    protected static final String NOT_LOGGED = "Cannot run this command when not logged in!";

    protected final String[] args;
    protected final CommandType type;
    protected final SocketChannel socket;

    public Command(String[] args, CommandType type, SocketChannel socket) {
        this.args = args;
        this.type = type;
        this.socket = socket;
    }

    public String command() {
        return type.getCommand();
    }

    public String[] arguments() {
        return args;
    }

    public abstract String execute();

    protected String jsonifyArguments(String status, String data) {
        JsonResponse<String> response = new JsonResponse<>(status, data);
        return GsonSingleton.getInstance().toJson(response);
    }

    protected String executeAddGroup() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, NOT_LOGGED);
        }

        User runner = UserSessionManager.getInstance().getUser(socket);
        Set<User> friends = Arrays.stream(args, USERNAME_IDX, args.length) // Start from index 1
            .map(username -> new User(username, "", ""))
            .collect(Collectors.toSet());

        for (User friend : friends) {
            if (!InMemoryExpenseRepository.getInstance().isRegistered(friend)) {
                return jsonifyArguments(ERROR, "User is not registered!");
            }
        }

        friends.add(runner);
        GroupRepository.getInstance().addGroup(runner, new Group("", friends));

        return jsonifyArguments(OK, "Friend successfully added!");
    }
}

package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense.Expense;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.Group;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.group.GroupRepository;

import java.nio.channels.SocketChannel;
import java.util.Set;

public class SplitCommand extends Command {
    private static final int AMOUNT_IDX = 0;
    private static final int USERNAME_IDX = 1;
    private static final int REASON_FOR_PAYMENT_IDX = 2;

    public SplitCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.SPLIT, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, NOT_LOGGED);
        }

        User runner = UserSessionManager.getInstance().getUser(socket);
        Group g = GroupRepository.getInstance()
            .getGroup(runner, new Group("", Set.of(new User(args[USERNAME_IDX], "", ""))));

        if (g == null) {
            return jsonifyArguments(ERROR, "Group does not exist!");
        }

        InMemoryExpenseRepository.getInstance()
            .addExpense(new Expense(AMOUNT_IDX, runner, g, args[REASON_FOR_PAYMENT_IDX]));

        return jsonifyArguments(OK, "Successfully added expense!");
    }
}

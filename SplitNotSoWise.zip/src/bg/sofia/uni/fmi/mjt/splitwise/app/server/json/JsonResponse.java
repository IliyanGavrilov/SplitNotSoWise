package bg.sofia.uni.fmi.mjt.splitwise.app.server.json;

public record JsonResponse<T>(String status, T data) {
}
package bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.Group;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public class Expense {
    private final UUID uuid;
    private final double amount;
    private final User credited; // The person who paid the expense
    private final Group debited; // The people who owe the person who paid
    private final String reasonForPayment;

    public Expense(double amount, User paidBy, Group debited, String reasonForPayment) {
        uuid = UUID.randomUUID();
        this.amount = amount;
        this.credited = paidBy;
        this.debited = debited;
        this.reasonForPayment = reasonForPayment;
    }

    public User getCredited() {
        return credited;
    }

    public double getAmount() {
        return amount;
    }

    public Set<User> getDebited(User user) {
        return debited.usersExcept(user);
    }

    public Set<User> getGroup() {
        return debited.users();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Expense that = (Expense) o;

        return Objects.equals(uuid, that.uuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uuid);
    }

    @Override
    public String toString() {
        return "Expense{" +
            ", amount = " + amount +
            ", debited = " + debited +
            ", reasonForPayment = '" + reasonForPayment + '\'' +
            '}';
    }
}

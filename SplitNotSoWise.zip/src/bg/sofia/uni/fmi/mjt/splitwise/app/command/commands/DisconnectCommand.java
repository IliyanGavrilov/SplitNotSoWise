package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;

public class DisconnectCommand extends Command {
    public DisconnectCommand(String[] args) {
        super(args, CommandType.DISCONNECT, null);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        return jsonifyArguments(OK, "User disconnected successfully!");
    }
}

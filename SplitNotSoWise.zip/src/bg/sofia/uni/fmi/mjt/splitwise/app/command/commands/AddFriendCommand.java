package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;

import java.nio.channels.SocketChannel;

public class AddFriendCommand extends Command {
    public AddFriendCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.ADD_FRIEND, socket);
    }

    @Override
    public String execute() {
        return executeAddGroup();
    }
}

package bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.group;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.Group;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

record GroupData(Map<User, Set<Group>> groups) implements Serializable {
}

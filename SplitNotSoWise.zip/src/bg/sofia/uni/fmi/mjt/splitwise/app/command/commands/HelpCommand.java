package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;

public class HelpCommand extends Command {
    public HelpCommand(String[] args) {
        super(args, CommandType.HELP, null);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        StringBuilder result2 = new StringBuilder();
        for (CommandType type : CommandType.values()) {
            result2.append(type).append('\n');
        }

        return jsonifyArguments(OK, result2.toString());
    }
}

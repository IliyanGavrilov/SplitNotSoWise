package bg.sofia.uni.fmi.mjt.splitwise.exception.handler;

import bg.sofia.uni.fmi.mjt.splitwise.api.dto.error.ErrorResponse;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.api.APIErrorException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.http.HttpException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.http.clienterror.BadRequestException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.http.clienterror.TooManyRequestsException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.http.clienterror.UnauthorizedException;
import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.http.servererror.InternalServerErrorException;

// TODO
public class ExceptionFactory {
    public static HttpException createHttpException(int statusCode, ErrorResponse errorResponse) throws HttpException {
        return createHttpException(HttpStatusCode.getFromCode(statusCode), errorResponse);
    }

    public static HttpException createHttpException(HttpStatusCode httpStatusCode, ErrorResponse errorResponse) {
        APIErrorException apiErrorException =
            createApiErrorException(errorResponse.getCode(), errorResponse.getMessage());

        return switch (httpStatusCode) {
            case HttpStatusCode.BAD_REQUEST ->
                new BadRequestException(HttpStatusCode.BAD_REQUEST.message(), apiErrorException);
            case HttpStatusCode.UNAUTHORIZED ->
                new UnauthorizedException(HttpStatusCode.UNAUTHORIZED.message(), apiErrorException);
            case HttpStatusCode.TOO_MANY_REQUESTS ->
                new TooManyRequestsException(HttpStatusCode.TOO_MANY_REQUESTS.message(), apiErrorException);
            case HttpStatusCode.INTERNAL_SERVER_ERROR ->
                new InternalServerErrorException(HttpStatusCode.INTERNAL_SERVER_ERROR.message(), apiErrorException);
            default -> new HttpException("Unexpected HTTP error: " + httpStatusCode, apiErrorException);
        };
    }

    private static APIErrorException createApiErrorException(int code, String message) {
        try {
            if (message == null || message.isBlank()) {
                return new APIErrorException(String.valueOf(code));
            }

            return new APIErrorException(code + ": " + message);
        } catch (NullPointerException e) {
            return new APIErrorException("API error code is null - " + message, e);
        }
    }
}
package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;

public class UnknownCommand extends Command {
    public UnknownCommand(String[] args) {
        super(args, CommandType.UNKNOWN, null);
    }

    @Override
    public String execute() {
        return jsonifyArguments(ERROR, "Unknown command!");
    }
}

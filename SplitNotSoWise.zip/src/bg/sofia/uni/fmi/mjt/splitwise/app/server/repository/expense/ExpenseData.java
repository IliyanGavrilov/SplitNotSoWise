package bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense.Expense;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

record ExpenseData(Map<User, List<Expense>> expenses, Map<User, Map<User, Double>> amountsOwed)
    implements Serializable {
}

package bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;

import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Map;

public class UserSessionManager {
    private final Map<SocketChannel, User> activeSessions = new HashMap<>();
    private static UserSessionManager instance;

    private UserSessionManager() {
    }

    public static UserSessionManager getInstance() {
        if (instance == null) {
            instance = new UserSessionManager();
        }

        return instance;
    }

    public boolean login(SocketChannel socketChannel, User user) {
        // Can check if user is logged in already, but I'll allow logging in from multiple instances simultaneously

        if (isLoggedIn(socketChannel)) {
            return false;
        }

        if (!InMemoryExpenseRepository.getInstance().validatePassword(user)) {
            return false;
        }

        activeSessions.put(socketChannel, user);
        return true;
    }

    public boolean logout(SocketChannel socketChannel) {
        if (!isLoggedIn(socketChannel)) {
            return false;
        }

        activeSessions.remove(socketChannel);
        return true;
    }

    public boolean isLoggedIn(SocketChannel socketChannel) {
        return activeSessions.containsKey(socketChannel);
    }

    public User getUser(SocketChannel socketChannel) {
        return activeSessions.get(socketChannel);
    }
}

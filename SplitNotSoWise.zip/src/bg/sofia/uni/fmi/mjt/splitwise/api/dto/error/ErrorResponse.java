package bg.sofia.uni.fmi.mjt.splitwise.api.dto.error;

import bg.sofia.uni.fmi.mjt.splitwise.api.dto.BaseResponse;
import com.google.gson.annotations.SerializedName;

public class ErrorResponse extends BaseResponse {
    private static final boolean STATUS = false;
    private final int code;
    @SerializedName("info")
    private final String message;

    public ErrorResponse(int code, String message) {
        super(STATUS);
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}

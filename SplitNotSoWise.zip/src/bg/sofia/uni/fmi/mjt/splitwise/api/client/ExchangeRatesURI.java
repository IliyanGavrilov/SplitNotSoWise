package bg.sofia.uni.fmi.mjt.splitwise.api.client;

import bg.sofia.uni.fmi.mjt.splitwise.exception.exceptions.ExchangeAPIException;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

// TODO
public class ExchangeRatesURI {
    private static final String API_ENDPOINT_SCHEME = "https";
    private static final String API_ENDPOINT_HOST = "api.exchangeratesapi.io";
    private static final String API_ENDPOINT_PATH = "/v1/convert";

    private static final String API_ENDPOINT_QUERY = "access_key=%s&from=%s&to=%s&amount=%s";
    private static final String API_ENDPOINT_DATE_QUERY = "&date=%s";

    // Required parameters
    private final String apiKey;
    private final String from;
    private final String to;
    private final int amount;

    // Optional parameters
    private final String date;

    private ExchangeRatesURI(ExchangeRatesURIBuilder builder) {
        this.apiKey = builder.apiKey;
        this.from = builder.from;
        this.to = builder.to;
        this.amount = builder.amount;
        this.date = builder.date;
    }

    public URI buildURI() throws URISyntaxException {
        // Mandatory parameters
        StringBuilder query = new StringBuilder();
        query.append(String.format(API_ENDPOINT_QUERY, apiKey, from, to, amount));

        // Optional parameters
        if (date != null && !date.isEmpty()) {
            query.append(String.format(API_ENDPOINT_DATE_QUERY, date));
        }

        return new URI(API_ENDPOINT_SCHEME, API_ENDPOINT_HOST, API_ENDPOINT_PATH, query.toString(), null);
    }

    public static class ExchangeRatesURIBuilder {
        private static final int MIN_PAGE_SIZE = 1;
        private static final int MAX_PAGE_SIZE = 100;
        private static final int MIN_PAGE = 0;

        // Required parameters
        private final String apiKey;
        private final String from;
        private final String to;
        private final int amount;

        // Optional parameters
        private String date;

        private boolean isValidDate(String date) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate parsedDate = LocalDate.parse(date, formatter);
                return true;
            } catch (DateTimeParseException e) {
                return false;
            }
        }

        public ExchangeRatesURIBuilder(String apiKey, String from, String to, int amount) throws ExchangeAPIException {
            this.apiKey = apiKey;
            this.from = from;
            this.to = to;
            this.amount = amount;
        }

        public ExchangeRatesURI build() {
            return new ExchangeRatesURI(this);
        }

        public ExchangeRatesURIBuilder withDate(String date) throws ExchangeAPIException {
            // Maybe leave it up to the API?
            if (!isValidDate(date)) {
                throw new ExchangeAPIException("Invalid date format or value. Expected format: YYYY-MM-DD");
            }

            this.date = date;

            return this;
        }
    }
}

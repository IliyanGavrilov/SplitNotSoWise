package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense.InMemoryExpenseRepository;

import java.nio.channels.SocketChannel;

public class PaymentHistoryCommand extends Command {
    public PaymentHistoryCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.PAYMENT_HISTORY, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (!UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, NOT_LOGGED);
        }
        User runner = UserSessionManager.getInstance().getUser(socket);

        return jsonifyArguments(OK, InMemoryExpenseRepository.getInstance().getHistory(runner).toString());
    }
}

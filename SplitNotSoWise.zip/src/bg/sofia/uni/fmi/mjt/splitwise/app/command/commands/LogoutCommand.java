package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;

import java.nio.channels.SocketChannel;

public class LogoutCommand extends Command {
    public LogoutCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.LOGOUT, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        if (UserSessionManager.getInstance().logout(socket)) {
            return jsonifyArguments(OK, "User successfully logged out!");
        }

        return jsonifyArguments(ERROR, "Logout failed! User is not logged in!");
    }
}

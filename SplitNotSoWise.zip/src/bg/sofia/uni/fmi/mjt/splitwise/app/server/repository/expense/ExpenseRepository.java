package bg.sofia.uni.fmi.mjt.splitwise.app.server.repository.expense;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.expense.Expense;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.util.List;
import java.util.Map;

public interface ExpenseRepository {
    void addUser(User user);

    void addExpense(Expense expense);

    void pay(Expense expense, User debited);

    Double getDebtStatus(User credited, User debited);

    Map<User, Double> getStatus(User user);

    Map<User, Double> getStatusCreditsOnly(User user);

    Map<User, Double> getStatusEvenOnly(User user);

    Map<User, Double> getStatusDebtsOnly(User user);

    public List<Expense> getHistory(User user);

    boolean isRegistered(User user);

    boolean validatePassword(User user);

    User getUser(User user);
}

package bg.sofia.uni.fmi.mjt.splitwise.app.command;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.AddFriendCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.CreateGroupCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.DisconnectCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.HelpCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.LoginCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.LogoutCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.PayedCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.PaymentHistoryCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.RegisterCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.SplitCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.SplitGroupCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.StatusCommand;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.commands.UnknownCommand;

import java.nio.channels.SocketChannel;

public enum CommandType {
    LOGIN("login", new String[] {"<username>", "<password>"}, CommandArgumentsType.EXACT),
    LOGOUT("logout", new String[] {}, CommandArgumentsType.EXACT),
    REGISTER("register", new String[] {"<username>", "<password>", "<nickname>"}, CommandArgumentsType.AT_LEAST),
    ADD_FRIEND("add-friend", new String[] {"<username>"}, CommandArgumentsType.EXACT),
    CREATE_GROUP("create-group", new String[] {"<group_name>", "<username> <username> ..."},
        CommandArgumentsType.AT_LEAST),
    SPLIT("split", new String[] {"<amount>", "<username>", "<reason_for_payment>"}, CommandArgumentsType.EXACT),
    SPLIT_GROUP("split-group", new String[] {"<amount>", "<group_name>", "<reason_for_payment>"},
        CommandArgumentsType.EXACT),
    GET_STATUS("get-status", new String[] {}, CommandArgumentsType.EXACT),
    PAYED("payed", new String[] {"<amount>", "<username>"}, CommandArgumentsType.EXACT),
    PAYMENT_HISTORY("payment-history", new String[] {}, CommandArgumentsType.EXACT),
    HELP("help", new String[] {}, CommandArgumentsType.EXACT),
    DISCONNECT("disconnect", new String[] {}, CommandArgumentsType.EXACT),
    UNKNOWN("", new String[] {}, CommandArgumentsType.EXACT);

    private static final String INVALID_ARGS =
        "Invalid count of arguments: \"%s\" expects %d arguments. Example: \"%s\"";
    private static final String INSUFFICIENT_ARGS =
        "Invalid count of arguments: \"%s\" expects at least %d arguments. Example: \"%s\"";

    private final String command;
    private final String[] args;
    private final CommandArgumentsType argsType;

    CommandType(String command, String[] args, CommandArgumentsType argsType) {
        this.command = command;
        this.args = args;
        this.argsType = argsType;
    }

    public static CommandType fromString(String command) {
        for (CommandType type : values()) {
            if (type.command.equalsIgnoreCase(command)) {
                return type;
            }
        }
        return null;
    }

    public static Command getCommand(String command, SocketChannel channel,
                                     String[] args) {
        CommandType commandType = fromString(command);

        if (commandType == null) {
            return new UnknownCommand(args);
        }

        return switch (commandType) {
            case LOGIN -> new LoginCommand(args, channel);
            case LOGOUT -> new LogoutCommand(args, channel);
            case REGISTER -> new RegisterCommand(args);
            case ADD_FRIEND -> new AddFriendCommand(args, channel);
            case CREATE_GROUP -> new CreateGroupCommand(args, channel);
            case SPLIT -> new SplitCommand(args, channel);
            case SPLIT_GROUP -> new SplitGroupCommand(args, channel);
            case GET_STATUS -> new StatusCommand(args, channel); // TODO
            case PAYED -> new PayedCommand(args, channel);
            case PAYMENT_HISTORY -> new PaymentHistoryCommand(args, channel);
            case HELP -> new HelpCommand(args);
            case DISCONNECT -> new DisconnectCommand(args);
            default -> new UnknownCommand(args);
        };
    }

    public String checkArguments(int argCnt) {
        if ((argsType == CommandArgumentsType.EXACT && argCnt == args.length) ||
            (argsType == CommandArgumentsType.AT_LEAST && argCnt >= args.length)) {
            return null;
        }

        return String.format((argsType == CommandArgumentsType.EXACT ? INVALID_ARGS : INSUFFICIENT_ARGS),
            command, args.length, this);
    }

    public String getCommand() {
        return command;
    }

    @Override
    public String toString() {
        return command + ' ' + String.join(" ", args);
    }
}

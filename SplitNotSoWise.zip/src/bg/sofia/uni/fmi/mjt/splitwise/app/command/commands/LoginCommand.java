package bg.sofia.uni.fmi.mjt.splitwise.app.command.commands;

import bg.sofia.uni.fmi.mjt.splitwise.app.command.Command;
import bg.sofia.uni.fmi.mjt.splitwise.app.command.CommandType;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.Encryption;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.auth.UserSessionManager;
import bg.sofia.uni.fmi.mjt.splitwise.app.server.model.user.User;

import java.nio.channels.SocketChannel;

public class LoginCommand extends Command {
    private static final int USERNAME_IDX = 0;
    private static final int PASSWORD_IDX = 1;

    public LoginCommand(String[] args, SocketChannel socket) {
        super(args, CommandType.LOGIN, socket);
    }

    @Override
    public String execute() {
        String result = type.checkArguments(args.length);
        if (result != null) {
            return jsonifyArguments(ERROR, result);
        }

        String encryptedPassword = Encryption.encrypt(args[PASSWORD_IDX], args[USERNAME_IDX]);

        if (UserSessionManager.getInstance().isLoggedIn(socket)) {
            return jsonifyArguments(ERROR, "User is already logged in!");
        }

        try {
            if (UserSessionManager.getInstance().login(socket, new User(args[USERNAME_IDX], encryptedPassword, ""))) {
                return jsonifyArguments(OK, "User successfully logged in!");
            }

            return jsonifyArguments(ERROR, "Login failed! Invalid password!");
        } catch (RuntimeException e) {
            return jsonifyArguments(ERROR, e.getMessage() + "Invalid username!");
        }
    }
}

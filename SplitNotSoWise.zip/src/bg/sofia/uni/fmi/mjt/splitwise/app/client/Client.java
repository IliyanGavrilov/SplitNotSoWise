package bg.sofia.uni.fmi.mjt.splitwise.app.client;

import bg.sofia.uni.fmi.mjt.splitwise.app.server.ExpenseServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 7777;
    private static final int BUFFER_SIZE = 512;
    private static final ByteBuffer BUFFER = ByteBuffer.allocateDirect(BUFFER_SIZE);
    private static final int SERVER_STARTUP_DELAY = 1000;
    private static final String QUIT_COMMAND = "quit";

    public static void main(String[] args) {
        ExpenseServer server =
            new ExpenseServer(SERVER_PORT);

        Thread serverThread = startServerThread(server);

        runClient();

        stopServer(server, serverThread);
    }

    private static Thread startServerThread(ExpenseServer ps) {
        Thread serverThread = new Thread(() -> {
            try {
                ps.start();
            } catch (Exception e) {
                System.err.println("Server encountered an error: " + e.getMessage());
            }
        });

        serverThread.start();

        try {
            Thread.sleep(SERVER_STARTUP_DELAY);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return serverThread;
    }

    private static void runClient() {
        try (SocketChannel socketChannel = SocketChannel.open();
             Scanner scanner = new Scanner(System.in)) {

            socketChannel.connect(new InetSocketAddress(SERVER_HOST, SERVER_PORT));
            System.out.println("Connected to the server.");

            while (true) {
                System.out.print("Enter message: ");
                String message = scanner.nextLine(); // read a line from the console

                if (QUIT_COMMAND.equals(message)) break;

                sendMessage(socketChannel, message); // send message to server
                String reply = receiveMessage(socketChannel); // get reply from server
                System.out.println(reply); // display reply
            }
        } catch (IOException e) {
            throw new RuntimeException("There is a problem with the network communication", e);
        }
    }

    private static void sendMessage(SocketChannel socketChannel, String message) throws IOException {
        BUFFER.clear(); // switch to writing mode
        BUFFER.put(message.getBytes()); // buffer fill
        BUFFER.flip(); // switch to reading mode
        socketChannel.write(BUFFER); // buffer drain
    }

    private static String receiveMessage(SocketChannel socketChannel) throws IOException {
        BUFFER.clear(); // switch to writing mode
        socketChannel.read(BUFFER); // buffer fill
        BUFFER.flip(); // switch to reading mode

        byte[] byteArray = new byte[BUFFER.remaining()];
        BUFFER.get(byteArray); // buffer drain
        return new String(byteArray, StandardCharsets.UTF_8);
    }

    private static void stopServer(ExpenseServer ps, Thread serverThread) {
        ps.stop();

        try {
            serverThread.join(); // Wait for the server thread to terminate
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restore interrupt status
            System.err.println("Server thread was interrupted during shutdown.");
        }
    }
}
